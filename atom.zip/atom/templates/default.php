<?php
/**
* Template Name: Page Template Example
*/
?>

<h1>Page template example</h1>