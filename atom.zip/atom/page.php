<!-- Custom Page -->
<?php get_header(); ?>

<div class="page-custom">
    <div class="page-container"> 
        <?php the_content(); ?>
    </div>
</div>

<?php get_footer(); ?>

