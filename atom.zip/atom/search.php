<?php
get_header();

get_template_part('include/body', 'header');

get_template_part('include/body', 'main-search');

get_template_part('include/body', 'footer');

get_footer();
