<header>
	<?php
	get_template_part('include/header/part', 'topbar');
	get_template_part('include/header/part', 'menubar');
	?>
</header>