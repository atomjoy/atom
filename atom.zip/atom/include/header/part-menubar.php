<nav id="top-nav">
	<?php wp_nav_menu([
		'theme_location' => 'top-menu',
		'menu_class' => 'top-bar',
	]); ?>
</nav>