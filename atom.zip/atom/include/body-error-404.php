<h1 class="error404-title"><?php echo __('Error Page'); ?></h1>
<div class="error404-nr animate__animated animate__bounce"><?php echo __('404'); ?></div>
<p class="error404-text"><?php echo __('Oops! The page you are looking for does not exist.'); ?></p>