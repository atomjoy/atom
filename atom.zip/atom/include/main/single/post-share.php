<h3 class="title"><?php echo __('Social share'); ?></h3>
<?php shareSocial(get_permalink()); ?>