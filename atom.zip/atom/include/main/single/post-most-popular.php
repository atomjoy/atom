<h3 class="post-popular-post-title"><?php echo __('Most Popular Posts'); ?></h3>
<?php
// Show posts
mostPopularPosts();
?>