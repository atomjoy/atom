<div class="atom-widgets atom-widgets-right">
	<div class="page-sidebar-widget">
		<?php
		show_page_sidebar();
		?>
	</div>
</div>