<div class="left">
	© <?php echo __('All rights reserved since 2024'); ?>
	<?php echo __('Powerd by Atomjoy'); ?>
</div>
<?php wp_nav_menu([
	'theme_location' => 'footer-menu',
	'menu_class' => 'footer-bar',
]); ?>