<div class="container">
	<div class="flex-container">
		<div class="atom-post">
			<?php
			get_template_part('include/main/part', 'category');
			?>
		</div>

		<div class="atom-rightbar">
			<?php
			get_template_part('include/main/part', 'rightbar');
			?>
		</div>
	</div>
</div>