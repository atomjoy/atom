<div class="container">
	<div class="atom-post">
		<?php
		get_template_part('include/main/part', 'category');
		?>
	</div>
</div>