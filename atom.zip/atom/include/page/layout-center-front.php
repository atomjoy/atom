<div class="container">
	<div class="atom-post">
		<?php
		get_template_part('include/main/part', 'front');
		?>
	</div>
</div>