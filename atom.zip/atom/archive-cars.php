<?php

show_brands();
