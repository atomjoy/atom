<?php
// Default front page
?>

<?php get_header(); ?>

<div class="page-wrap">
	<div class="container">
		<?php get_template_part('include/section', 'front'); ?>
	</div>
</div>

<?php get_footer(); ?>