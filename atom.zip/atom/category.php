<!-- Category Page -->
<?php get_header(); ?>

<div class="page-wrap">
    <div class="container">        
        <?php get_template_part('include/section', 'category'); ?>
    </div>
</div>

<?php get_footer(); ?>