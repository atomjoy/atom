<?php
get_header();

get_template_part('include/body', 'header');

get_template_part('include/body', 'main-archive');

get_template_part('include/body', 'footer');

get_footer();
